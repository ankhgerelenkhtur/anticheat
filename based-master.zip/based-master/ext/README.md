﻿# ✨ Credits
- [minhook](https://github.com/TsudaKageyu/minhook)
- [x86retspoof](https://github.com/danielkrupinski/x86RetSpoof)
